# pxt-aqbit
MakeCode extension for AQ:bit.
<br/>
<br/>
## License
MIT License
<br/>
<br/>
## Supported targets

* for PXT/microbit
