{
    AQbit.connectToWiFiNetwork("SSID", "key")
}
